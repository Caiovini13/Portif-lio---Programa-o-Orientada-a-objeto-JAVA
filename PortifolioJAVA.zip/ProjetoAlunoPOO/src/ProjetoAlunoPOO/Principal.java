package ProjetoAlunoPOO;

public class Principal {
    public static void main(String[] args) {
        // Criando um objeto do tipo Aluno
        Aluno aluno1 = new Aluno("João Silva", "20231001", "Engenharia");

        // Exibindo informações do aluno
        aluno1.exibirInformacoes();

        // Matriculando o aluno em uma disciplina
        aluno1.matricularEmDisciplina("Matemática");

        // Cancelando a matrícula do aluno
        aluno1.cancelarMatricula();
    }
}
