package ProjetoAlunoPOO;

public class Aluno {
    // Atributos privados
    private String nome;
    private String matricula;
    private String curso;

    // Construtor
    public Aluno(String nome, String matricula, String curso) {
        this.nome = nome;
        this.matricula = matricula;
        this.curso = curso;
    }

    // Método para exibir informações do aluno
    public void exibirInformacoes() {
        System.out.println("Nome: " + nome);
        System.out.println("Matrícula: " + matricula);
        System.out.println("Curso: " + curso);
    }

    // Método para matricular em uma disciplina
    public void matricularEmDisciplina(String disciplina) {
        System.out.println(nome + " foi matriculado na disciplina: " + disciplina);
    }

    // Método para cancelar a matrícula
    public void cancelarMatricula() {
        System.out.println("A matrícula de " + nome + " foi cancelada.");
    }
}
